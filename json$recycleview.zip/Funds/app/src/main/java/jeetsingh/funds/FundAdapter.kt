package jeetsingh.funds

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import kotlinx.android.synthetic.main.custom_card.view.*


class FundAdapter(val FundList: ArrayList<Fund>, val context: Context)
    : RecyclerView.Adapter<FundAdapter.ViewHolder>() {


    override fun getItemCount(): Int {
        return FundList.size
    }

    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): FundAdapter.ViewHolder {
        val v = LayoutInflater.from(p0.context).inflate(R.layout.custom_card, p0, false)
        return ViewHolder(v)
    }


    override fun onBindViewHolder(p0: FundAdapter.ViewHolder, p1: Int) {
        if (setDate(FundList[p1].date).equals("01")||p1==0){
            p0.month.setVisibility(View.VISIBLE)
        }else{
            p0.month.setVisibility(View.GONE)
        }
        p0.date.text = "Day: "+setDate(FundList[p1].date)
        p0.percent.text = FundList[p1].percentChange.toString()
        p0.preTaxNav.text = FundList[p1].preTaxNav.toString()
        p0.month.text = setMonth(FundList[p1].date)

    }

    override fun getItemId(position: Int): Long {
        return super.getItemId(position)
    }

    class ViewHolder(v: View) : RecyclerView.ViewHolder(v) {
        val date = v.date_txt
        val preTaxNav = v.preTaxNav_txt
        val percent = v.percent_txt
        val month = v.month_txt

    }

    fun setDate(date:String):String{
        var temp = date.split("-")
        var temp2 = temp[2]

        return temp2.substring(0,2)



    }

    fun setMonth(date:String):String{
        var temp = date.split("-")
        var month = temp[1]
        if(month.equals("01")){
            return "January ${temp[0]}"
        }else if(month.equals("02")) {
            return "February ${temp[0]}"
        }else if(month.equals("03")){
            return "March ${temp[0]}"
        }else if(month.equals("04")) {
            return "April ${temp[0]}"
        }else if(month.equals("05")) {
            return "May ${temp[0]}"
        }else if(month.equals("06")) {
            return "June ${temp[0]}"
        }else if(month.equals("07")){
            return "July ${temp[0]}"
        }else if(month.equals("08")) {
            return "August ${temp[0]}"
        }else if(month.equals("09")){
            return "September ${temp[0]}"
        }else if(month.equals("10")) {
            return "October ${temp[0]}"
        }else if(month.equals("11")){
            return "November ${temp[0]}"
        }else {
            return "December ${temp[0]}"
        }
    }


}

