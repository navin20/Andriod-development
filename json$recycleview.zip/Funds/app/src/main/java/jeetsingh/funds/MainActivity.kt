package jeetsingh.funds

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.LinearLayoutManager
import android.util.Log
import android.widget.LinearLayout
import com.google.gson.Gson
import kotlinx.android.synthetic.main.activity_main.*
import org.json.JSONArray
import java.util.*


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var list = ArrayList<Fund>()

        var foundJson = assets.open("btp-nav.json").bufferedReader().use {
            it.readText()
        }
        var gson = Gson()



        val jsonArray = JSONArray(foundJson)

        for (i in 0..jsonArray.length() - 1) {
            var f :Fund
            f = gson.fromJson(jsonArray[i].toString(), Fund::class.java)
            list.add(f)

        }

        list.sortWith(compareBy({it.date}))
        list.reverse()

        val rView = recyclerView
        rView.layoutManager = LinearLayoutManager(this, LinearLayout.VERTICAL,false)

        var adapter = FundAdapter(list,this)
        rView.adapter = adapter


    }


}