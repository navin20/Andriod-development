package jeetsingh.funds

data class Fund(var date:String, var preTaxNav:Double, var preTaxOffer:Double, var preTaxBid:Double, var fundSize:Long, var change: Double, var percentChange:Double)


