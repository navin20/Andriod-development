package com.example.andriodclass.monthapplication

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.google.gson.annotations.JsonAdapter
import kotlinx.android.synthetic.main.customcell.view.*

class StudentAdapter(val dataList: ArrayList<Post>):RecyclerView.Adapter<StudentAdapter.ViewHolder>() {
    override fun getItemCount(): Int {
        return dataList.size
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.customcell, parent, false)
        val newView = ViewHolder(v)
        return newView
    }

    override fun onBindViewHolder(viewHolder: StudentAdapter.ViewHolder, p1: Int) {
        var date = dataList[p1].date;
        var data1 = dataList[p1].preTaxNav.toString()
        var data2 = dataList[p1].preTaxBid.toString()
        viewHolder.date.text = date;
        viewHolder.data1.text = data1;
        viewHolder.data2.text = data2;
        viewHolder.itemView.setOnClickListener {
        }
    }

    class ViewHolder(v: View) : RecyclerView.ViewHolder(v) {
        val date = v.date_tv
        val data1 = v.preTax_tv
        val data2 = v.percent_tv
    }
}
