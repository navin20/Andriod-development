package com.example.andriodclass.monthapplication

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.util.Log
import android.widget.LinearLayout

import com.google.gson.Gson
import kotlinx.android.synthetic.main.activity_main.*
import org.json.JSONArray
import java.io.BufferedReader
import java.io.File
import java.io.InputStream
import java.io.InputStreamReader

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var list = ArrayList<Post>()
        var j = assets.open("btp-nav.json").bufferedReader().use {
            it.readText()
        }
        var gson = Gson()

        val jsonArray = JSONArray(j)
        for (i in 0..jsonArray.length()-1){
            var f = gson.fromJson(jsonArray[i].toString(),Post::class.java)
            list.add(f)
        }
        val rView = recyclerView
        rView.layoutManager = LinearLayoutManager(this, LinearLayout.VERTICAL, false)
        var adapter = StudentAdapter(list)
        rView.adapter = adapter

//            Log.e("Heyy",jsonArray[0].toString())
//        val jjSon: String = applicationContext.assets.open("fundshow.json").bufferedReader().use {
//            it.readText()
//        }

    }
}
