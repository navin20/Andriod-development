package com.example.andriodclass.monthapplication

data class Post     (val change: Double,
val date: String,
val fundSize: Long,
val percentChange: Double,
val preTaxBid: Double,
val preTaxNav: Double,
val preTaxOffer: Double
)

