## Lecture note week 3
### Question
1. Where should I place scripts?
    - How to make Access Modifiers in kotlin?
    - Sould I write accessor?
2. What are meaning of those function?
    + getItemCount(): Int
    + onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder
    + onBindViewHolder(viewHolder: StudentAdapter.ViewHolder, p1: Int)
