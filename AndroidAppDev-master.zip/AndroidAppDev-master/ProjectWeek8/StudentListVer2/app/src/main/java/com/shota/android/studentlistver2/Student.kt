package com.shota.android.studentlistver2

data class Student(val id: String,val name: String) {

}