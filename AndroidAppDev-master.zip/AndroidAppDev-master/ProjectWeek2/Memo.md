## Lecture note
### Change company comain
 - Comapany domain (not example.com)

### SDK settings
 - choose supportable machine type
	- phone and tab
	- android tv

### Activity to mobile
 - First page that you make in this project
 - 

### in java file
 - 3 library
	- your logic file (.kt)

in resources foldar
 - Layout folder
	- .xml file of your activity