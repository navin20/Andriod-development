# AndroidAppDev Repository
This repository is for store android project which I create in "Android application development".

Each week directory have `MEMO.md` file for lecture note which summize each week lecture.

## Index
* [LentBorrow](https://github.com/ShotaKu/AndroidAppDev/tree/master/LentBorrow)
    1. Term project files
* [Project week 1](https://github.com/ShotaKu/AndroidAppDev/tree/master/ProjectWeek1)
    1. Lean about instration of Android studio with kotlin useable setting.
    2. Create first project and run without any error.
    3. Create hello world app.
    4. [Update] change project to add calculation application to learn kotlin besic.
* [Project week 2](https://github.com/ShotaKu/AndroidAppDev/tree/master/ProjectWeek2)
    1. Create simple calculation application.
    2. Try to use only one onClick function to 5 buttons.
* [Project week 3](https://github.com/ShotaKu/AndroidAppDev/tree/master/ProjectWeek3)
    1. Create recycler view.
    2. Create student list as in-class execise.
    3. Use Toast message.
* [Project week 4](https://github.com/ShotaKu/AndroidAppDev/tree/master/ProjectWeek4)
    1. Term project Presentation.
    2. Question memo.
* Project week 5
    1. No class.
* [Project week 6](https://github.com/ShotaKu/AndroidAppDev/tree/master/ProjectWeek6)
    1. Using google map API and show university maps.
    2. Create pokemon map app.
    3. Create pokemon map app which player will auto walk to all pokemons.
* [Project week 7](https://github.com/ShotaKu/AndroidAppDev/tree/master/ProjectWeek7)
    1. Quiz 1
    2. Create university map with faculty logo.
* [Project week 8](https://github.com/ShotaKu/AndroidAppDev/tree/master/ProjectWeek8)
    1. Create application which has 2 activity pages and swtich them.
    2. Create student list app which can see detail student information if tap on list card.
* [Project week 9](https://github.com/ShotaKu/AndroidAppDev/tree/master/ProjectWeek9)
    1. Get JSON from API
    2. Parse JSON to object class
* [Project week 10](https://github.com/ShotaKu/AndroidAppDev/tree/master/ProjectWeek10)
    1. Put JSON file on local app folder
    2. Read JSON file from local folder
* [Project week 11](https://github.com/ShotaKu/AndroidAppDev/tree/master/ProjectWeek11)
    1. Connect to Firebase
    2. Login Firebase Authentication
    3. Read/write value on Firebase real tile database
* [Project week 12](https://github.com/ShotaKu/AndroidAppDev/tree/master/ProjectWeek12)
    1. Save/load value in local strage
* README.md
    - This file