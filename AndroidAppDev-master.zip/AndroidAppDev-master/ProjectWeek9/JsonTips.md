## Lecture note week 9
### What is JSON Object and array?
Tips: JSON object = collection of data which wrapped by ```{ }``` such as...
```JSON
{
    film:{
        id: "2baf70d1-42bb-4437-b551-e5fed5a87abe",
        title: "Castle in the Sky",
        description: "The orphan Sheeta inherited a mysterious crystal that links her to the mythical sky-kingdom of Laputa. With the help of resourceful Pazu and a rollicking band of sky pirates, she makes her way to the ruins of the once-great civilization. Sheeta and Pazu must outwit the evil Muska, who plans to use Laputa's science to make himself ruler of the world.",
        director: "Hayao Miyazaki",
        producer: "Isao Takahata",
        release_date: "1986",
        rt_score: "95",
        people: [
        "https://ghibliapi.herokuapp.com/people/"
        ],
        species: [
        "https://ghibliapi.herokuapp.com/species/af3910a6-429f-4c74-9ad5-dfe1c4aa04f2"
        ],
        locations: [
        "https://ghibliapi.herokuapp.com/locations/"
        ],
        vehicles: [
        "https://ghibliapi.herokuapp.com/vehicles/"
        ],
        url: "https://ghibliapi.herokuapp.com/films/2baf70d1-42bb-4437-b551-e5fed5a87abe"
    }
}
```
This is an example of object(Film) in JSON from [StudioGhibli API](https://ghibliapi.herokuapp.com/). Object which wrapped by ```{ }``` is object and it has fields and value. I was writen like ```fieldName:"Values"```

Tips: JSON array = collection of data which wrapped by ```[ ]``` such as...
```JSON
{
    array: [1,2,3],
    arrayObject:[{
        id: "2baf70d1-42bb-4437-b551-e5fed5a87abe",
        title: "Castle in the Sky",
    },
    {
        id: "12cfb892-aac0-4c5b-94af-521852e46d6a",
        title: "Grave of the Fireflies",
    }] 
}
```