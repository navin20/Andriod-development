package com.shota.android.readjsonfromapi

data class Dog(val name: String){

}