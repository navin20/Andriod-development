package com.shota.studentlistapp

data class Student(val id: String,val name: String){

}